let formularioVisivel = false;
let servicoAtual = "";

function mostrarFormulario(servico) {
  const form = document.getElementById('form-servico');
  const tipoInput = document.getElementById('tipo_servico');

  if (formularioVisivel && servicoAtual === servico) {
    form.classList.remove('visivel');
    formularioVisivel = false;
    servicoAtual = "";
    return;
  }

  tipoInput.value = servico;
  form.classList.add('visivel');
  formularioVisivel = true;
  servicoAtual = servico;
}
