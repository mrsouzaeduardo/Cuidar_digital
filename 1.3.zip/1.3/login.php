<?php
$serverName = "localhost\\SQLEXPRESS"; // Ou IP do servidor
$connectionOptions = [
    "Database" => "cuidar_digital",
    "Uid" => "seu_usuario",
    "PWD" => "sua_senha",
    "CharacterSet" => "UTF-8"
];

$conn = sqlsrv_connect($serverName, $connectionOptions);

if (!$conn) {
    die("Falha na conexão: " . print_r(sqlsrv_errors(), true));
}

$email = $_POST['email'];
$senha = $_POST['senha'];

$sql = "SELECT * FROM usuarios WHERE email = ? AND senha = ?";
$params = [$email, $senha]; // Para segurança, ideal usar hash

$stmt = sqlsrv_query($conn, $sql, $params);

if ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
    echo "Login realizado com sucesso. Bem-vindo(a) " . $row['nome'];
    // Aqui pode redirecionar para painel do usuário
} else {
    echo "Email ou senha inválidos.";
}
?>
